// Script simple para animar testimonios en loop
const testimonios = [
  "“Muchas gracias Maestro, volvió en 72 h.”",
  "“Excelente ayuda, mi vida cambió.”",
  "“Nunca pensé que fuera tan rápido, estoy feliz.”"
];

let i = 0;
setInterval(() => {
  const testimonioBox = document.querySelector(".testimonials p");
  if (testimonioBox) {
    testimonioBox.textContent = testimonios[i];
    i = (i + 1) % testimonios.length;
  }
}, 4000);
